<?php
// CORS Configuration for Techtornix API
function handleCORS() {
    // Load environment variables
    $corsOrigin = $_ENV['CORS_ORIGIN'] ?? 'https://techtornix.com';
    
    // Set CORS headers
    header("Access-Control-Allow-Origin: $corsOrigin");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Max-Age: 3600");
    
    // Handle preflight OPTIONS request
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
}

// Set JSON content type
function setJSONHeaders() {
    header('Content-Type: application/json; charset=utf-8');
}

// Handle CORS for all API requests
handleCORS();
?>
